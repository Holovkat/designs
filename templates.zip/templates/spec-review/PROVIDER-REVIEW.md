# Provider / Model Review

## Context
- Link to functional design briefs and instructional guides driving this evaluation.

## Evaluation Matrix
| Criterion | Observation | Risk | Mitigation |
| --- | --- | --- | --- |

## Test Notes
- Describe prompts, datasets, or sandbox environments used (no production code).

## Decision & Follow-ups
- State go/no-go recommendation, required owners, and deadlines.
