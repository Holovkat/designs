# Process Guide Title

## Scenario
- Reference the originating functional-design brief (e.g., `20-CODEX-47-ALIGNMENT-DESIGN-STEPS.md`).

## Roles & RACI
- List facilitator, reviewers, approvers, contributors.

## Step-by-Step Ritual
1. Kickoff checklist
2. Execution cadence
3. Exit criteria

## Artifacts Produced
- Enumerate worksheets, prompt templates, validation notes.

## Handover Notes
- Clarify what must be delivered to engineering or operations teams.
