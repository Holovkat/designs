# NN-TOPIC-TITLE

> Use double-digit prefixes (e.g., `30-NEW-ORCHESTRATION-PATH.md`) to maintain chronological ordering. Write titles in SCREAMING-SNAKE-CASE with hyphens so they sort cleanly.

## Purpose
- Summarize the problem statement, target release, and connection to previous briefs.

## Current State
- Capture what is known today (metrics, user pain, architecture diagrams referenced by filename).

## Proposed Changes
- Use bullet lists, tables, or pseudo-DSL snippets to communicate design intent.

## Validation Plan
- Outline experiments, review gates, and artifacts required before engineering starts.

## Open Questions
- Track unresolved assumptions with owners and due dates.
